/**
 * DulyNoted Namespace
 * Loads first to establish shared namespace for content script classes.
 */
window.DulyNoted = window.DulyNoted || {};
